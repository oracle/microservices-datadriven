sudo yum-config-manager --add-repo https://rpm.releases.hashicorp.com/RHEL/hashicorp.repo
sudo yum-config-manager --enable ol8_developer  --enablerepo ol8_developer_EPEL
sudo dnf -y update
sudo yum install -y python36
sudo yum install -y oci-ansible-collection
sudo python -m pip install oci oci-cli
sudo dnf module install -y go-toolset
sudo yum install -y jdk-16.0.1.0.1.x86_64
sudo yum install -y git
sudo dnf install -y gnupg2 curl tar
sudo dnf install -y @ruby
sudo dnf install -y @nodejs:14
#sudo dnf install -y oracle-instantclient-release-el8 oraclelinux-developer-release-el8
sudo dnf install -y node-oracledb-node14
sudo yum install -y oci-dotnet-sdk
sudo yum -y install maven
#sudo dnf install -y oracle-database-preinstall-19c
sudo yum install -y libnsl
sudo yum remove -y oracle-instantclient-basic libclntsh

sudo rpm -i https://yum.oracle.com/repo/OracleLinux/OL8/oracle/instantclient/x86_64/getPackage/oracle-instantclient19.11-basic-19.11.0.0.0-1.x86_64.rpm
sudo rpm -i https://yum.oracle.com/repo/OracleLinux/OL8/oracle/instantclient/x86_64/getPackage/oracle-instantclient19.11-sqlplus-19.11.0.0.0-1.x86_64.rpm
sudo rpm -i https://yum.oracle.com/repo/OracleLinux/OL8/oracle/instantclient/x86_64/getPackage/oracle-instantclient19.11-tools-19.11.0.0.0-1.x86_64.rpm

curl -sL https://github.com/graalvm/graalvm-ce-builds/releases/download/vm-20.1.0/graalvm-ce-java11-linux-amd64-20.1.0.tar.gz | tar xz
~/graalvm-ce-java11-20.1.0/bin/gu install native-image

#kubcetl, minikube, docker, docker registry
